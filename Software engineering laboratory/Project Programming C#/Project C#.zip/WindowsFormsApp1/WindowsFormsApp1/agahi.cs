﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class agahi : Form
    {
        public agahi()
        {
            InitializeComponent();
            this.pictureBox1=new System.Windows.Forms.PictureBox();
            this.SuspendLayout();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            main main = new main();
            this.Hide();
            main.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filepath = openFileDialog.FileName;
                pictureBox1.Image = new Bitmap(filepath);
            }
            if (pictureBox1 != null)
            {
                MemoryStream ms = new MemoryStream();
                pictureBox1.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                byte[] photobyte = ms.ToArray();
                
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            string text = "افزودن عکس";
            Font font=new Font("Arial",10,FontStyle.Bold);
            Brush brush=new SolidBrush(Color.Red);
            PointF point = new PointF(10, 10);
            g.DrawString(text,font, brush, point);  
        }

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            string text = "افزودن عکس";
            Font font = new Font("Arial", 10, FontStyle.Bold);
            Brush brush = new SolidBrush(Color.Red);
            PointF point = new PointF(10, 10);
            g.DrawString(text, font, brush, point);
        }

        private void pictureBox3_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            string text = "افزودن عکس";
            Font font = new Font("Arial", 10, FontStyle.Bold);
            Brush brush = new SolidBrush(Color.Red);
            PointF point = new PointF(10, 10);
            g.DrawString(text, font, brush, point);
        }

        private void pictureBox4_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            string text = "افزودن عکس";
            Font font = new Font("Arial", 10, FontStyle.Bold);
            Brush brush = new SolidBrush(Color.Red);
            PointF point = new PointF(10, 10);
            g.DrawString(text, font, brush, point);
        }

        private void pictureBox5_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            string text = "افزودن عکس";
            Font font = new Font("Arial", 10, FontStyle.Bold);
            Brush brush = new SolidBrush(Color.Red);
            PointF point = new PointF(10, 10);
            g.DrawString(text, font, brush, point);
        }

        private void pictureBox6_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            string text = "افزودن عکس";
            Font font = new Font("Arial", 10, FontStyle.Bold);
            Brush brush = new SolidBrush(Color.Red);
            PointF point = new PointF(10, 10);
            g.DrawString(text, font, brush, point);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text=="" && textBox2.Text=="")
            {
                MessageBox.Show("کامل کردن تمام فیلد ها اجباری میباشد");
            }
            else if (textBox3.Text == "" && textBox4.Text == "")
            {
                MessageBox.Show("کامل کردن تمام فیلد ها اجباری میباشد");
            }
            else if (textBox5.Text == "" && textBox6.Text == "")
            {
                MessageBox.Show("کامل کردن تمام فیلد ها اجباری میباشد");
            }
            else
            {
                MessageBox.Show("درخواست شما ثبت و در دست بررسی قرار گرفت");
                main main=new main();
                this.Hide();
                main.Show();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filepath = openFileDialog.FileName;
                pictureBox1.Image = new Bitmap(filepath);
            }
            if (pictureBox1 != null)
            {
                MemoryStream ms = new MemoryStream();
                pictureBox1.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                byte[] photobyte = ms.ToArray();
              
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filepath = openFileDialog.FileName;
                pictureBox1.Image = new Bitmap(filepath);
            }
            if (pictureBox1 != null)
            {
                MemoryStream ms = new MemoryStream();
                pictureBox1.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                byte[] photobyte = ms.ToArray();
                
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filepath = openFileDialog.FileName;
                pictureBox1.Image = new Bitmap(filepath);
            }
            if (pictureBox1 != null)
            {
                MemoryStream ms = new MemoryStream();
                pictureBox1.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                byte[] photobyte = ms.ToArray();
                
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filepath = openFileDialog.FileName;
                pictureBox1.Image = new Bitmap(filepath);
            }
            if (pictureBox1 != null)
            {
                MemoryStream ms = new MemoryStream();
                pictureBox1.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                byte[] photobyte = ms.ToArray();
                
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filepath = openFileDialog.FileName;
                pictureBox1.Image = new Bitmap(filepath);
            }
            if (pictureBox1 != null)
            {
                MemoryStream ms = new MemoryStream();
                pictureBox1.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                byte[] photobyte = ms.ToArray();
                
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}
