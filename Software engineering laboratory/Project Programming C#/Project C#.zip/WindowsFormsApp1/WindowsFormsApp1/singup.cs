﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class singup : Form
    {
        public string gender;
        public singup()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("نام خود را وارد کنید");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("نام خانوادگی خود را وارد کنید");
            }
            else if(textBox3.Text == "")
            {
                MessageBox.Show("تاریخ تولد خود را وارد کنید");
            }
            
            else if (textBox5.Text == "")
            {
                MessageBox.Show("شهر خود را وارد کنید");
            }
            if (radioButton1.Checked)
            {
                gender = "مرد";
            }
            if (radioButton2.Checked)
            {
                gender = "زن";
            }
            else if(textBox6.Text == "")
            {
                MessageBox.Show("رمزعبور خود را وارد کنید");
            }
            else if (textBox4.Text == "")
            {
                MessageBox.Show("نام کاربری خود را وارد کنید");
            }
            else if (textBox7.Text == "")
            {
                MessageBox.Show("تکرار رمز عبور خود را وارد کنید");
            }
            else if (textBox6.Text != textBox7.Text)
            {
                MessageBox.Show("تکرار رمز عبور نادرست میباشد");
            }
            else
            {
                OleDbConnection con = new OleDbConnection();
                con.ConnectionString = "Provider=Microsoft.ace.oledb.12.0;data source=tenantfinder.accdb";
                con.Open();
                OleDbCommand command = new OleDbCommand();
                command.CommandText = "insert into [tenite]([name],[fname],[dateborn],[gender],[city],[uname],[password]) values(?,?,?,?,?,?,?)";
                command.Parameters.AddWithValue("@name", textBox1.Text);
                command.Parameters.AddWithValue("@fname", textBox2.Text);
                command.Parameters.AddWithValue("@deteborn", textBox3.Text);
                command.Parameters.AddWithValue("@gender", gender);
                command.Parameters.AddWithValue("@city", textBox5.Text);
                command.Parameters.AddWithValue("@uname", textBox4.Text);
                command.Parameters.AddWithValue("@password", textBox7.Text);
                command.Connection = con;
                command.ExecuteNonQuery();
                MessageBox.Show("ثبت نام موفیقت آمیز بود");
                con.Close();
                Form1 form1 = new Form1();
                this.Hide();
                form1.Show();
                
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
