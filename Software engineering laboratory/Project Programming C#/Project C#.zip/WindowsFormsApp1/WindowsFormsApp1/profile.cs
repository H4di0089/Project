﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class profile : Form
    {
        public string gender;
        public profile()
        {
            InitializeComponent();
        }

        private void profile_Load(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = "Provider=Microsoft.ace.oledb.12.0;Data Source=tenantfinder.accdb";
            con.Open();
            OleDbCommand com = new OleDbCommand();
            com.CommandText = "SELECT * FROM [tenite] WHERE [uname]=?";
            com.Parameters.AddWithValue("@uname",Properties.Settings.Default.userlog);
            com.Connection = con;
            OleDbDataReader reader = com.ExecuteReader();
            if (reader.Read())
            {
                textBox1.Text = reader["name"].ToString();
                textBox2.Text = reader["fname"].ToString();
                textBox3.Text = reader["dateborn"].ToString();
                textBox5.Text = reader["city"].ToString();
                textBox4.Text = reader["uname"].ToString();
                textBox6.Text = reader["password"].ToString();
                


                    if (reader["picture"] != DBNull.Value)
                    {
                    byte[] image = (byte[])reader["picture"];
                    using (MemoryStream ms = new MemoryStream(image))
                    {
                        pictureBox1.Image = Image.FromStream(ms);
                        con.Close();
                    }
                }
                else
                {
                    pictureBox1.Image = null;
                    con.Close();

                }
            }
            else
            {


                MessageBox.Show("Error");


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filepath = openFileDialog.FileName;
                pictureBox1.Image = new Bitmap(filepath);
            }
            if (pictureBox1 != null)
            {
                MemoryStream ms = new MemoryStream();
                pictureBox1.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                byte[] photobyte = ms.ToArray();
                savePhotoToDatabase(photobyte);
            }
        }
        private void savePhotoToDatabase(byte[] photobyte)
        {
            string username = Properties.Settings.Default.userlog;
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = "Provider=Microsoft.ace.oledb.12.0;Data Source=tenantfinder.accdb";
            con.Open();
            OleDbCommand com = new OleDbCommand();
            com.CommandText = "UPDATE [tenite] SET [picture]=@picture where [uname]=@unname ";
            com.Connection = con;
            com.Parameters.AddWithValue("@picture", photobyte);
            com.Parameters.AddWithValue("@uname", username);

            int row = (int)com.ExecuteNonQuery();
            if (row > 0)
            {
                con.Close();

                MessageBox.Show("عکس تغییر کرد");
            }
            else
            {
                con.Close();

                MessageBox.Show("مشکلی پیش آمده لطفا بعدا تلاش کنید");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            main main = new main();
            this.Hide();
            main.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (radioButton1.Checked || radioButton2.Checked)
            {
                if (textBox1.Text == "")
                {
                    MessageBox.Show("نام خود را وارد کنید");
                }
                else if (textBox2.Text == "")
                {
                    MessageBox.Show("نام خانوادگی خود را وارد کنید");
                }
                else if (textBox3.Text == "")
                {
                    MessageBox.Show("تاریخ تولد خود را وارد کنید");
                }

                else if (textBox5.Text == "")
                {
                    MessageBox.Show("شهر خود را وارد کنید");
                }
                if (radioButton1.Checked)
                {
                    gender = "مرد";
                }
                if (radioButton2.Checked)
                {
                    gender = "زن";
                }
                else if (textBox6.Text == "")
                {
                    MessageBox.Show("رمزعبور خود را وارد کنید");
                }
                else if (textBox4.Text == "")
                {
                    MessageBox.Show("نام کاربری خود را وارد کنید");
                }
                else
                {
                    string username = Properties.Settings.Default.userlog;
                    OleDbConnection con = new OleDbConnection();
                    con.ConnectionString = "Provider=Microsoft.ace.oledb.12.0;Data Source=tenantfinder.accdb";
                    con.Open();
                    OleDbCommand com = new OleDbCommand();
                    com.CommandText = "Update [tenite] set [name]=?,[fname]=?,[dateborn]=?,[gender]=?,[city]=?,[uname]=?,[password]=? WHERE [uname]=? ";
                    com.Connection = con;
                    com.Parameters.AddWithValue("@name", textBox1.Text);
                    com.Parameters.AddWithValue("@fname", textBox2.Text);
                    com.Parameters.AddWithValue("@dateborn", textBox3.Text);
                    com.Parameters.AddWithValue("@gender", gender);
                    com.Parameters.AddWithValue("@password", textBox6.Text);
                    com.Parameters.AddWithValue("@city", textBox5.Text);
                    com.Parameters.AddWithValue("@uname", textBox4.Text);
                    com.Parameters.AddWithValue("@uname", username);
                    int raw = (int)com.ExecuteNonQuery();
                    con.Close();

                    if (raw > 0)
                    {
                        Properties.Settings.Default.userlog = textBox4.Text;
                        Properties.Settings.Default.Save();
                        MessageBox.Show("تغییرات اعمال شد");


                    }
                    else
                    {
                        MessageBox.Show("مشکلی پیش آمده لطفا بعدا تلاش کنید");
                    }
                }
            }
            else
            {
                MessageBox.Show("جنسیت را مشخص کنید");
            }
                
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = "Provider=Microsoft.ace.oledb.12.0;Data Source=tenantfinder.accdb";
            con.Open();
            OleDbCommand com = new OleDbCommand();
            com.CommandText = "UPDATE [tenite] SET [picture]=? WHERE [uname]=?";
            string username = Properties.Settings.Default.userlog.ToString();
            com.Parameters.AddWithValue("@picture", DBNull.Value);

            com.Parameters.AddWithValue("@uname", username);

            com.Connection = con;
            int count = (int)com.ExecuteNonQuery();
            if (count == 1)
            {
                MessageBox.Show("عکس حذف شد");
                profile form2 = new profile();
                this.Hide();
                con.Close();
                form2.Show();
            }
            else
            {
                MessageBox.Show("مشکلی پیش آمده لطفا بعدا تلاش کنید");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.login = false;
            Properties.Settings.Default.Save();
            Properties.Settings.Default.userlog = null;
            Properties.Settings.Default.Save();

            this.Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }
    }
}
