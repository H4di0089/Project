﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void املاکToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

            Form2 form2 = new Form2();
            this.Hide();
            form2.Show();

        }

        private void پروفایلToolStripMenuItem_Click(object sender, EventArgs e)
        {
            profile profile = new profile();
            this.Hide();
            profile.Show();
        }

        private void ثبتآگاهیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            agahi agahi = new agahi();
            this.Hide();
            agahi.Show();


        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void پنلمشاورانToolStripMenuItem_Click(object sender, EventArgs e)
        {
            moshaver moshaver = new moshaver();
            this.Hide();
            moshaver.Show();
        }

        private void خدماتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel3.Height=panel1.Height;
            panel1.Location=new Point(5, 5);
            panel3.Location = new Point(0, 0);
            panel1.BringToFront();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            buy buy = new buy();
            this.Hide(); buy.Show();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            bazsazi bazsazi = new bazsazi();
            this.Hide(); bazsazi.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            tarahi tarahi = new tarahi();   
            this.Hide(); tarahi.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            lavazem lavazem = new lavazem();
            this.Hide();
            lavazem.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            rahsazi rahsazi = new rahsazi();
            this.Hide();
            rahsazi.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            nezarat nezarat = new nezarat();
            this.Hide();
            nezarat.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            masaleh masaleh = new masaleh();    
            this.Hide(); masaleh.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            MessageBox.Show("به زودی در دسترس قرار میگیرد");
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
