﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class moshaver : Form
    {
        public string gender;
        public moshaver()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("نام خود را وارد کنید");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("");
            }
            else if(textBox3.Text == "نام خانوادگی خود را وارد کنید")
            {
                MessageBox.Show("");
            }
            else if (textBox4.Text == "")
            {
                MessageBox.Show("شماره جواز اجباری میباشد");
            }
            else if (textBox5.Text == "")
            {
                MessageBox.Show("شماره عضویت اجباری میباشد");
            }
            if (radioButton1.Checked)
            {
                gender = "مرد";
            }
            if (radioButton2.Checked)
            {
                gender = "زن";
            }
            else
            {
                OleDbConnection con = new OleDbConnection();
                con.ConnectionString = "Provider=Microsoft.ace.oledb.12.0;data source=tenantfinder.accdb";
                con.Open();
                OleDbCommand com = new OleDbCommand();
                com.CommandText = "insert into [moshaver]([gender],[fname],[lname],[javaz],[join],[city]) values(?,?,?,?,?,?)";
                com.Parameters.AddWithValue("@gender", gender);
                com.Parameters.AddWithValue("@fname", textBox1.Text);
                com.Parameters.AddWithValue("@lname", textBox2.Text);
                com.Parameters.AddWithValue("@javaz", textBox3.Text);
                com.Parameters.AddWithValue("@join", textBox4.Text);
                com.Parameters.AddWithValue("@city", textBox5.Text);
                com.Connection = con;
                com.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("با موفیقت ثبت شد");
                main main = new main();
                this.Hide();
                main.Show();
            }
        }

        private void بازگشتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            main main = new main();
            this.Hide();
            main.Show();
        }

        private void حروجToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
